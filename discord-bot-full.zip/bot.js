const { Client, GatewayIntentBits } = require("discord.js");
const express = require("express");
const mc = require("minecraft-server-util");
require("dotenv").config();

const app = express();
app.get("/", (req, res) => res.send("Bot is alive!"));
app.listen(process.env.PORT || 3000, () => console.log("🌍 Keep-alive server running"));

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates
  ],
});

const prefix = "!";
const adminRoleId = process.env.ADMIN_ROLE_ID;
let userPermissions = {};
let warnings = {};

function hasPermission(user, perm) {
  const perms = userPermissions[user.id] || new Set();
  return perms.has("all") || perms.has(perm);
}

client.once("ready", () => console.log(`✅ Logged in as ${client.user.tag}`));

client.on("messageCreate", async (msg) => {
  if (!msg.content.startsWith(prefix) || msg.author.bot) return;
  const args = msg.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if(command === "announce") {
    if(!hasPermission(msg.author,"announce")) return msg.reply("❌ No permission.");
    const text = args.join(" ");
    if(!text) return msg.reply("⚠️ Usage: !announce message");
    msg.channel.send(`📢 ${text}`);
  }

  if(command==="lock") {
    if(!hasPermission(msg.author,"lock")) return msg.reply("❌ No permission.");
    await msg.channel.permissionOverwrites.edit(msg.guild.roles.everyone, {SendMessages:false});
    msg.reply("🔒 Channel locked!");
  }

  if(command==="unlock") {
    if(!hasPermission(msg.author,"lock")) return msg.reply("❌ No permission.");
    await msg.channel.permissionOverwrites.edit(msg.guild.roles.everyone, {SendMessages:true});
    msg.reply("🔓 Channel unlocked!");
  }

  if(command==="mute") {
    if(!hasPermission(msg.author,"mute")) return msg.reply("❌ No permission.");
    const member = msg.mentions.members.first();
    if(!member) return msg.reply("⚠️ Usage: !mute @user");
    let muteRole = msg.guild.roles.cache.find(r=>r.name==="Muted");
    if(!muteRole){
      muteRole = await msg.guild.roles.create({name:"Muted",permissions:[]});
      msg.guild.channels.cache.forEach(async ch=>{
        await ch.permissionOverwrites.edit(muteRole,{SendMessages:false,Speak:false});
      });
    }
    await member.roles.add(muteRole);
    msg.reply(`🔇 ${member} has been muted.`);
  }

  if(command==="unmute") {
    if(!hasPermission(msg.author,"mute")) return msg.reply("❌ No permission.");
    const member = msg.mentions.members.first();
    if(!member) return msg.reply("⚠️ Usage: !unmute @user");
    let muteRole = msg.guild.roles.cache.find(r=>r.name==="Muted");
    if(muteRole && member.roles.cache.has(muteRole.id)){
      await member.roles.remove(muteRole);
      msg.reply(`🔊 ${member} has been unmuted.`);
    } else msg.reply("⚠️ That user isn’t muted.");
  }

  if(command==="ban"){
    if(!hasPermission(msg.author,"ban")) return msg.reply("❌ No permission.");
    const member = msg.mentions.members.first();
    if(!member) return msg.reply("⚠️ Usage: !ban @user");
    await member.ban({reason:"Banned by bot command"});
    msg.reply(`🔨 ${member.user.tag} was banned.`);
  }

  if(command==="unban"){
    if(!hasPermission(msg.author,"ban")) return msg.reply("❌ No permission.");
    const userId = args[0];
    if(!userId) return msg.reply("⚠️ Usage: !unban userId");
    try { await msg.guild.members.unban(userId); msg.reply(`✅ User with ID ${userId} has been unbanned.`);}
    catch{ msg.reply("⚠️ Could not unban that user.");}
  }

  if(command==="warn"){
    if(!hasPermission(msg.author,"warn")) return msg.reply("❌ No permission.");
    const member = msg.mentions.members.first();
    const reason = args.slice(1).join(" ") || "No reason provided";
    if(!member) return msg.reply("⚠️ Usage: !warn @user reason");
    if(!warnings[member.id]) warnings[member.id]=[];
    warnings[member.id].push(reason);
    msg.reply(`⚠️ ${member} has been warned. Reason: ${reason}`);
  }

  if(command==="smp" && args[0]==="status"){
    const ip=args[1];
    if(!ip) return msg.reply("⚠️ Usage: !smp status <ip>");
    try {
      const result = await mc.status(ip,25565);
      msg.reply(`✅ SMP **${ip}** is online!
Players: ${result.players.online}/${result.players.max}`);
    } catch { msg.reply(`❌ Could not reach SMP server ${ip}`); }
  }

  if(command==="givepermission"){
    if(!msg.member.roles.cache.has(adminRoleId)) return msg.reply("❌ No permission.");
    const member = msg.mentions.members.first();
    const perm = args[1]?.toLowerCase();
    if(!member||!perm) return msg.reply("⚠️ Usage: !givepermission @user permission");
    if(!userPermissions[member.id]) userPermissions[member.id]=new Set();
    if(perm==="all") userPermissions[member.id]=new Set(["all"]);
    else userPermissions[member.id].add(perm);
    msg.reply(`✅ ${member} now has ${perm} permission.`);
  }

});

client.login(process.env.TOKEN);
