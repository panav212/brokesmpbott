# Discord Bot

## Setup
1. Add your bot token and admin role ID as environment variables in Render:
```
TOKEN=your_bot_token
ADMIN_ROLE_ID=your_admin_role_id
```
2. Run locally:
```
npm install
npm start
```
3. On Render, upload this folder as a zip and set the same environment variables.
